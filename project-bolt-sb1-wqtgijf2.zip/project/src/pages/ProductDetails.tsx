import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Star, Heart, ShoppingCart, Truck, Shield, RotateCcw, MessageCircle } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

const ProductDetails = () => {
  const { id } = useParams();
  const { addItem } = useCart();
  const [selectedColor, setSelectedColor] = useState('rose-gold');
  const [selectedWrapping, setSelectedWrapping] = useState('elegant');
  const [personalMessage, setPersonalMessage] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Mock product data - in real app, this would come from API
  const product = {
    id: '1',
    name: 'Romantic Valentine Package',
    price: 89.99,
    originalPrice: 119.99,
    rating: 4.8,
    reviewCount: 124,
    category: "Valentine's Day",
    description: 'A beautifully curated Valentine\'s Day package that includes premium chocolates, a handwritten card, elegant roses, and a special surprise gift. Perfect for expressing your love and creating unforgettable moments.',
    features: [
      'Premium Belgian chocolates',
      'Fresh roses bouquet',
      'Handwritten greeting card',
      'Special surprise gift',
      'Beautiful gift wrapping',
      'Personal message option'
    ],
    images: [
      'https://images.pexels.com/photos/1666065/pexels-photo-1666065.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1098365/pexels-photo-1098365.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/265856/pexels-photo-265856.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1028714/pexels-photo-1028714.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    colors: [
      { name: 'Rose Gold', value: 'rose-gold', color: '#E8B4B8' },
      { name: 'Classic Red', value: 'classic-red', color: '#DC2626' },
      { name: 'Soft Pink', value: 'soft-pink', color: '#F9A8D4' },
      { name: 'Pure White', value: 'pure-white', color: '#FFFFFF' }
    ],
    wrappingOptions: [
      { name: 'Elegant Box', value: 'elegant', price: 0 },
      { name: 'Premium Wrapping', value: 'premium', price: 5.99 },
      { name: 'Luxury Gift Bag', value: 'luxury', price: 8.99 }
    ]
  };

  const reviews = [
    {
      id: 1,
      user: 'Sarah M.',
      rating: 5,
      comment: 'Absolutely beautiful package! My partner was so surprised and touched. Everything was perfect.',
      date: '2 days ago'
    },
    {
      id: 2,
      user: 'Mike R.',
      rating: 5,
      comment: 'High quality items and beautiful presentation. Will definitely order again!',
      date: '1 week ago'
    },
    {
      id: 3,
      user: 'Emma L.',
      rating: 4,
      comment: 'Lovely package, arrived on time. The chocolates were delicious!',
      date: '2 weeks ago'
    }
  ];

  const handleAddToCart = () => {
    const wrappingOption = product.wrappingOptions.find(w => w.value === selectedWrapping);
    const totalPrice = product.price + (wrappingOption?.price || 0);

    addItem({
      id: `${product.id}-${selectedColor}-${selectedWrapping}`,
      name: product.name,
      price: totalPrice,
      image: product.images[0],
      color: selectedColor,
      wrapping: selectedWrapping,
      message: personalMessage
    });
  };

  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
  const selectedWrappingOption = product.wrappingOptions.find(w => w.value === selectedWrapping);
  const totalPrice = product.price + (selectedWrappingOption?.price || 0);

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400 mb-8 animate-fade-in">
          <Link to="/" className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors">
            Home
          </Link>
          <span>/</span>
          <Link to="/shop" className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors">
            Shop
          </Link>
          <span>/</span>
          <span className="text-gray-900 dark:text-white">{product.name}</span>
        </div>

        {/* Back Button */}
        <Link
          to="/shop"
          className="inline-flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors mb-8 animate-fade-in"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Shop</span>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Image Gallery */}
          <div className="animate-slide-up">
            <div className="glassmorphism dark:glassmorphism-dark rounded-2xl p-6">
              <div className="mb-6">
                <img
                  src={product.images[activeImageIndex]}
                  alt={product.name}
                  className="w-full h-96 object-cover rounded-xl"
                />
              </div>
              
              <div className="grid grid-cols-4 gap-4">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveImageIndex(index)}
                    className={`h-20 rounded-lg overflow-hidden transition-all duration-300 ${
                      activeImageIndex === index
                        ? 'ring-2 ring-purple-500 ring-offset-2 dark:ring-offset-gray-800'
                        : 'hover:opacity-80'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Product Info */}
          <div className="animate-slide-up space-y-8">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400 text-sm font-medium rounded-full">
                    {product.category}
                  </span>
                  {discount > 0 && (
                    <span className="px-3 py-1 bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-400 text-sm font-medium rounded-full">
                      -{discount}% OFF
                    </span>
                  )}
                </div>
                <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                  <Heart className="h-6 w-6 text-gray-400 hover:text-red-500 transition-colors" />
                </button>
              </div>

              <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white mb-4">
                {product.name}
              </h1>

              <div className="flex items-center space-x-4 mb-6">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating)
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                  <span className="text-gray-600 dark:text-gray-400 ml-2">
                    {product.rating} ({product.reviewCount} reviews)
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-3 mb-6">
                <span className="text-3xl font-bold text-gray-900 dark:text-white">
                  ${totalPrice.toFixed(2)}
                </span>
                {product.originalPrice && (
                  <span className="text-xl text-gray-500 line-through">
                    ${product.originalPrice}
                  </span>
                )}
              </div>

              <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-8">
                {product.description}
              </p>

              {/* Color Selection */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Color Theme
                </h3>
                <div className="flex space-x-3">
                  {product.colors.map((color) => (
                    <button
                      key={color.value}
                      onClick={() => setSelectedColor(color.value)}
                      className={`w-12 h-12 rounded-full border-2 transition-all duration-300 ${
                        selectedColor === color.value
                          ? 'border-purple-500 ring-2 ring-purple-200 dark:ring-purple-800'
                          : 'border-gray-300 dark:border-gray-600 hover:border-purple-400'
                      }`}
                      style={{ backgroundColor: color.color }}
                      title={color.name}
                    />
                  ))}
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                  Selected: {product.colors.find(c => c.value === selectedColor)?.name}
                </p>
              </div>

              {/* Wrapping Options */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Gift Wrapping
                </h3>
                <div className="space-y-3">
                  {product.wrappingOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => setSelectedWrapping(option.value)}
                      className={`w-full p-4 text-left border rounded-xl transition-all duration-300 ${
                        selectedWrapping === option.value
                          ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:border-purple-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900 dark:text-white">
                          {option.name}
                        </span>
                        <span className="text-gray-600 dark:text-gray-400">
                          {option.price > 0 ? `+$${option.price}` : 'Free'}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Personal Message */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Personal Message (Optional)
                </h3>
                <textarea
                  value={personalMessage}
                  onChange={(e) => setPersonalMessage(e.target.value)}
                  placeholder="Write a heartfelt message for your loved one..."
                  rows={4}
                  className="w-full p-4 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm border border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 resize-none"
                  maxLength={200}
                />
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                  {personalMessage.length}/200 characters
                </p>
              </div>

              {/* Add to Cart */}
              <div className="glassmorphism dark:glassmorphism-dark rounded-2xl p-6">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                    >
                      -
                    </button>
                    <span className="text-xl font-semibold w-8 text-center text-gray-900 dark:text-white">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                    >
                      +
                    </button>
                  </div>
                  
                  <button
                    onClick={handleAddToCart}
                    className="flex-1 btn-gradient text-white font-semibold py-4 px-8 rounded-xl hover:shadow-xl transform hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-2"
                  >
                    <ShoppingCart className="h-5 w-5" />
                    <span>Add to Cart</span>
                  </button>
                </div>

                {/* Shipping Info */}
                <div className="space-y-3 text-sm">
                  <div className="flex items-center space-x-3 text-gray-600 dark:text-gray-400">
                    <Truck className="h-5 w-5 text-green-500" />
                    <span>Free shipping on orders over $75</span>
                  </div>
                  <div className="flex items-center space-x-3 text-gray-600 dark:text-gray-400">
                    <Shield className="h-5 w-5 text-blue-500" />
                    <span>100% satisfaction guarantee</span>
                  </div>
                  <div className="flex items-center space-x-3 text-gray-600 dark:text-gray-400">
                    <RotateCcw className="h-5 w-5 text-purple-500" />
                    <span>Easy 30-day returns</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Features */}
        <div className="mt-16 glassmorphism dark:glassmorphism-dark rounded-2xl p-8 animate-fade-in">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
            What's Included
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {product.features.map((feature, index) => (
              <div
                key={index}
                className="flex items-center space-x-3 animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-2 h-2 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full" />
                <span className="text-gray-700 dark:text-gray-300">{feature}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Reviews */}
        <div className="mt-16 animate-fade-in">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              Customer Reviews
            </h2>
            <button className="flex items-center space-x-2 btn-gradient text-white px-6 py-3 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all duration-300">
              <MessageCircle className="h-5 w-5" />
              <span>Write Review</span>
            </button>
          </div>
          
          <div className="space-y-6">
            {reviews.map((review) => (
              <div key={review.id} className="glassmorphism dark:glassmorphism-dark rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                      {review.user[0]}
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 dark:text-white">
                        {review.user}
                      </h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {review.date}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < review.rating
                            ? 'text-yellow-400 fill-current'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                  {review.comment}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;