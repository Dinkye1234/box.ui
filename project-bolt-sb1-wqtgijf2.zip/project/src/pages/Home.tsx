import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Gift, Heart, Truck, Shield, Sparkles, Zap } from 'lucide-react';
import ProductCard, { Product } from '../components/ProductCard';

const Home = () => {
  const featuredProducts: Product[] = [
    {
      id: '1',
      name: 'Romantic Valentine Package',
      price: 89.99,
      originalPrice: 119.99,
      image: 'https://images.pexels.com/photos/1666065/pexels-photo-1666065.jpeg?auto=compress&cs=tinysrgb&w=500',
      rating: 4.8,
      reviewCount: 124,
      category: "Valentine's Day",
      isSale: true
    },
    {
      id: '2',
      name: 'Birthday Celebration Box',
      price: 65.99,
      image: 'https://images.pexels.com/photos/1587927/pexels-photo-1587927.jpeg?auto=compress&cs=tinysrgb&w=500',
      rating: 4.9,
      reviewCount: 89,
      category: 'Birthday',
      isNew: true
    },
    {
      id: '3',
      name: 'Luxury Spa Experience',
      price: 129.99,
      image: 'https://images.pexels.com/photos/3992204/pexels-photo-3992204.jpeg?auto=compress&cs=tinysrgb&w=500',
      rating: 4.7,
      reviewCount: 156,
      category: 'Self Care'
    },
    {
      id: '4',
      name: 'Sweet Treats Collection',
      price: 45.99,
      originalPrice: 59.99,
      image: 'https://images.pexels.com/photos/1028714/pexels-photo-1028714.jpeg?auto=compress&cs=tinysrgb&w=500',
      rating: 4.6,
      reviewCount: 203,
      category: 'Food & Treats',
      isSale: true
    }
  ];

  const categories = [
    {
      name: "Valentine's Day",
      image: 'https://images.pexels.com/photos/1666065/pexels-photo-1666065.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'from-pink-500 to-red-500'
    },
    {
      name: 'Birthday',
      image: 'https://images.pexels.com/photos/1587927/pexels-photo-1587927.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'from-yellow-500 to-orange-500'
    },
    {
      name: "Mother's Day",
      image: 'https://images.pexels.com/photos/1098365/pexels-photo-1098365.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'from-purple-500 to-pink-500'
    },
    {
      name: 'Anniversary',
      image: 'https://images.pexels.com/photos/265856/pexels-photo-265856.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'from-blue-500 to-purple-500'
    }
  ];

  const features = [
    {
      icon: <Gift className="h-8 w-8" />,
      title: 'Curated Collections',
      description: 'Expertly chosen gifts for every occasion and personality'
    },
    {
      icon: <Truck className="h-8 w-8" />,
      title: 'Fast Delivery',
      description: 'Express shipping available with same-day delivery options'
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: 'Quality Guarantee',
      description: '100% satisfaction guarantee on every gift purchase'
    },
    {
      icon: <Heart className="h-8 w-8" />,
      title: 'Personal Touch',
      description: 'Custom messages and beautiful wrapping included'
    }
  ];

  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-pink-100 via-purple-50 to-mint-100 dark:from-gray-900 dark:via-purple-900 dark:to-gray-800" />
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-64 h-64 bg-pink-300/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-purple-300/20 rounded-full blur-3xl animate-pulse delay-1000" />
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-mint-300/10 rounded-full blur-3xl animate-pulse delay-500" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="animate-slide-up">
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
              Perfect Gifts for
              <span className="gradient-text block">Every Moment</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
              Discover beautifully curated gift packages that create unforgettable memories. From birthdays to anniversaries, we have the perfect present for everyone you love.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Link
                to="/shop"
                className="btn-gradient text-white font-semibold px-8 py-4 rounded-full inline-flex items-center space-x-2 hover:shadow-xl transform hover:scale-105 transition-all duration-300"
              >
                <span>Shop Now</span>
                <ArrowRight className="h-5 w-5" />
              </Link>
              <button className="px-8 py-4 bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm text-gray-900 dark:text-white font-semibold rounded-full hover:bg-white/90 dark:hover:bg-gray-800/90 transition-all duration-300 border border-white/20">
                Learn More
              </button>
            </div>

            {/* AI Suggestion Feature */}
            <div className="glassmorphism dark:glassmorphism-dark rounded-2xl p-6 max-w-2xl mx-auto animate-scale-in">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <Sparkles className="h-6 w-6 text-purple-500" />
                <span className="font-semibold text-gray-900 dark:text-white">AI Gift Finder</span>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Let our AI help you find the perfect gift based on personality, occasion, and preferences
              </p>
              <button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-medium py-3 rounded-xl hover:from-purple-600 hover:to-pink-600 transform hover:scale-105 transition-all duration-300">
                <Zap className="h-4 w-4 inline mr-2" />
                Find My Perfect Gift
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-white/30 dark:bg-gray-900/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-slide-up">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Shop by Occasion
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Find the perfect gift for any celebration or milestone
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <Link
                key={category.name}
                to="/shop"
                className="group relative overflow-hidden rounded-2xl h-64 hover-lift animate-fade-in"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <img
                  src={category.image}
                  alt={category.name}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${category.color} opacity-60 group-hover:opacity-70 transition-opacity duration-300`} />
                <div className="absolute inset-0 flex items-end p-6">
                  <h3 className="text-white font-bold text-xl group-hover:transform group-hover:translate-y-[-4px] transition-transform duration-300">
                    {category.name}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-slide-up">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Featured Gifts
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Our most popular and highly-rated gift packages
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map((product, index) => (
              <div
                key={product.id}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <ProductCard product={product} />
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link
              to="/shop"
              className="inline-flex items-center space-x-2 btn-gradient text-white font-semibold px-8 py-4 rounded-full hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              <span>View All Products</span>
              <ArrowRight className="h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-800 dark:to-purple-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-slide-up">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Why Choose GiftBox?
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              We make gift-giving effortless and memorable
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={feature.title}
                className="text-center p-6 animate-fade-in"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl flex items-center justify-center text-white mx-auto mb-6 transform hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 bg-gradient-to-r from-pink-500 to-purple-500 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-10 left-20 w-32 h-32 bg-white/10 rounded-full blur-xl animate-pulse" />
          <div className="absolute bottom-10 right-20 w-48 h-48 bg-white/10 rounded-full blur-xl animate-pulse delay-1000" />
        </div>
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="animate-slide-up">
            <h2 className="text-4xl font-bold text-white mb-4">
              Never Miss a Special Moment
            </h2>
            <p className="text-xl text-pink-100 mb-8 max-w-2xl mx-auto">
              Get exclusive access to new collections, special offers, and personalized gift recommendations
            </p>
            
            <div className="flex flex-col sm:flex-row max-w-md mx-auto gap-4">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-6 py-4 rounded-full bg-white/20 backdrop-blur-sm text-white placeholder-pink-200 border border-white/30 focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent"
              />
              <button className="px-8 py-4 bg-white text-purple-600 font-semibold rounded-full hover:bg-pink-50 transform hover:scale-105 transition-all duration-300">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;